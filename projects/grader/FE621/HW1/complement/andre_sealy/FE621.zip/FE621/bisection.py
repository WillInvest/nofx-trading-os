from math import exp

from black_scholes import bs_call, bs_put


def implied_vol(option_type, bid, ask, S, K, r, T):
    epsilon = 1e-6

    option_price = (bid + ask) / 2.0
    if option_price <= 0 or T <= 0 or S <= 0 or K <= 0:
        return None

    discK = K * exp(-r * T)

    # No-arbitrage bounds: if violated, IV does not exist
    if option_type == "c":
        lower = max(S - discK, 0.0)
        upper = S
    else:
        lower = max(discK - S, 0.0)
        upper = discK

    if option_price < lower - 1e-12 or option_price > upper + 1e-12:
        return None

    def f(sigma):
        if option_type == "c":
            return bs_call(S, K, T, r, sigma) - option_price
        else:
            return bs_put(S, K, T, r, sigma) - option_price

    # Bracket the root
    a = 1e-6
    b = 1.0
    fa = f(a)
    fb = f(b)
    while fa * fb > 0 and b < 10.0:
        b *= 2.0
        fb = f(b)

    if fa * fb > 0:
        return None  # couldn't bracket => treat as no IV

    # Bisection
    for _ in range(200):
        mid = 0.5 * (a + b)
        fmid = f(mid)
        if abs(fmid) < epsilon or (b - a) < epsilon:
            return mid
        if fa * fmid <= 0:
            b = mid
            fb = fmid
        else:
            a = mid
            fa = fmid

    return 0.5 * (a + b)
